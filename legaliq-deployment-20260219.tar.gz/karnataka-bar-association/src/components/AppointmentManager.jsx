import React, { useState, useEffect } from 'react';
import './AppointmentManager.css';
import VideoConsultation from './VideoConsultation';

const AppointmentManager = ({ userEmail }) => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('upcoming');
  const [activeVideoCall, setActiveVideoCall] = useState(null);

  useEffect(() => {
    fetchAppointments();
  }, [userEmail]);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:4000/api/consultations?email=${userEmail}`);
      const data = await response.json();
      
      if (data.success) {
        setAppointments(data.consultations);
      }
    } catch (error) {
      console.error('Error fetching appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredAppointments = () => {
    const now = new Date();
    
    switch (activeTab) {
      case 'upcoming':
        return appointments.filter(apt => {
          const aptDate = new Date(apt.preferredDate);
          return aptDate >= now && apt.status !== 'completed' && apt.status !== 'cancelled';
        });
      case 'past':
        return appointments.filter(apt => {
          const aptDate = new Date(apt.preferredDate);
          return aptDate < now || apt.status === 'completed';
        });
      case 'cancelled':
        return appointments.filter(apt => apt.status === 'cancelled');
      default:
        return appointments;
    }
  };

  const handleStartVideoCall = (appointment) => {
    setActiveVideoCall(appointment);
  };

  const handleEndVideoCall = async (callData) => {
    try {
      // Update appointment status
      await fetch(`http://localhost:4000/api/consultations/${activeVideoCall.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          status: 'completed',
          videoCallData: callData
        }),
      });

      setActiveVideoCall(null);
      fetchAppointments();
      alert('Video consultation completed successfully!');
    } catch (error) {
      console.error('Error ending video call:', error);
      alert('Failed to update consultation status');
    }
  };

  const handleCancelAppointment = async (appointmentId) => {
    if (!window.confirm('Are you sure you want to cancel this appointment?')) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:4000/api/consultations/${appointmentId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          status: 'cancelled'
        }),
      });

      if (response.ok) {
        alert('Appointment cancelled successfully');
        fetchAppointments();
      }
    } catch (error) {
      console.error('Error cancelling appointment:', error);
      alert('Failed to cancel appointment');
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'status-pending',
      confirmed: 'status-confirmed',
      completed: 'status-completed',
      cancelled: 'status-cancelled'
    };

    return (
      <span className={`status-badge ${statusClasses[status] || ''}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const filteredAppointments = getFilteredAppointments();

  if (activeVideoCall) {
    return (
      <VideoConsultation
        consultation={activeVideoCall}
        onClose={() => setActiveVideoCall(null)}
        onEndCall={handleEndVideoCall}
      />
    );
  }

  return (
    <div className="appointment-manager">
      <div className="appointment-header">
        <h2>My Consultations</h2>
        <button className="btn-refresh" onClick={fetchAppointments}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
            <path d="M4 2v6h6M16 18v-6h-6M17.65 6.35A8 8 0 1 0 6.35 17.65" stroke="currentColor" strokeWidth="2" fill="none"/>
          </svg>
          Refresh
        </button>
      </div>

      <div className="appointment-tabs">
        <button
          className={`tab ${activeTab === 'upcoming' ? 'active' : ''}`}
          onClick={() => setActiveTab('upcoming')}
        >
          Upcoming
        </button>
        <button
          className={`tab ${activeTab === 'past' ? 'active' : ''}`}
          onClick={() => setActiveTab('past')}
        >
          Past
        </button>
        <button
          className={`tab ${activeTab === 'cancelled' ? 'active' : ''}`}
          onClick={() => setActiveTab('cancelled')}
        >
          Cancelled
        </button>
      </div>

      <div className="appointments-list">
        {loading ? (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Loading appointments...</p>
          </div>
        ) : filteredAppointments.length === 0 ? (
          <div className="empty-state">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            <h3>No {activeTab} appointments</h3>
            <p>You don't have any {activeTab} consultations at the moment.</p>
          </div>
        ) : (
          filteredAppointments.map((appointment) => (
            <div key={appointment.id} className="appointment-card">
              <div className="appointment-card-header">
                <div className="lawyer-info">
                  <div className="lawyer-avatar-small">
                    {appointment.lawyerName.split(' ')[1]?.[0] || appointment.lawyerName[0]}
                  </div>
                  <div>
                    <h3>{appointment.lawyerName}</h3>
                    <p className="case-type">{appointment.caseType}</p>
                  </div>
                </div>
                {getStatusBadge(appointment.status)}
              </div>

              <div className="appointment-details">
                <div className="detail-item">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                    <line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" strokeWidth="2"/>
                    <line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" strokeWidth="2"/>
                    <line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" strokeWidth="2"/>
                  </svg>
                  <span>{formatDate(appointment.preferredDate)}</span>
                </div>
                <div className="detail-item">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14" stroke="white" strokeWidth="2" fill="none"/>
                  </svg>
                  <span>{appointment.preferredTime}</span>
                </div>
                <div className="detail-item">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                  <span>{appointment.name}</span>
                </div>
              </div>

              <div className="appointment-description">
                <strong>Case Description:</strong>
                <p>{appointment.caseDescription}</p>
              </div>

              <div className="appointment-actions">
                {appointment.status === 'pending' && activeTab === 'upcoming' && (
                  <>
                    <button
                      className="btn-start-call"
                      onClick={() => handleStartVideoCall(appointment)}
                    >
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/>
                      </svg>
                      Start Video Call
                    </button>
                    <button
                      className="btn-cancel"
                      onClick={() => handleCancelAppointment(appointment.id)}
                    >
                      Cancel
                    </button>
                  </>
                )}
                {appointment.status === 'completed' && (
                  <div className="completed-info">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                      <polyline points="22 4 12 14.01 9 11.01" stroke="white" strokeWidth="2" fill="none"/>
                    </svg>
                    <span>Consultation Completed</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AppointmentManager;
