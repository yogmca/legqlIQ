import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import Homepage from './components/Homepage';
import Login from './components/Login';
import Register from './components/Register';
import SearchBar from './components/SearchBar';
import FilterSection from './components/FilterSection';
import LawyerCard from './components/LawyerCard';
import AppointmentManager from './components/AppointmentManager';
import { lawyerService } from './services/lawyerService';
import authService from './services/authService';

// Lawyers Directory Component
function LawyersDirectory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('All Specializations');
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [lawyers, setLawyers] = useState([]);
  const [totalLawyers, setTotalLawyers] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [offset, setOffset] = useState(0);
  const limit = 12;

  useEffect(() => {
    fetchInitialLawyers();
  }, []);

  useEffect(() => {
    if (searchTerm || selectedSpecialization !== 'All Specializations' || selectedLocation !== 'All Locations') {
      performSearch();
    }
  }, [searchTerm, selectedSpecialization, selectedLocation]);

  const fetchInitialLawyers = async () => {
    setLoading(true);
    try {
      const result = await lawyerService.fetchInitialLawyers(limit);
      setLawyers(result.data);
      setTotalLawyers(result.total);
      setHasMore(result.hasMore);
      setOffset(limit);
    } catch (error) {
      console.error('Error fetching lawyers:', error);
    } finally {
      setLoading(false);
    }
  };

  const performSearch = async () => {
    setLoading(true);
    try {
      const result = await lawyerService.searchLawyers(
        searchTerm,
        selectedSpecialization,
        selectedLocation,
        0,
        limit
      );
      setLawyers(result.data);
      setTotalLawyers(result.total);
      setHasMore(result.hasMore);
      setOffset(limit);
    } catch (error) {
      console.error('Error searching lawyers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLoadMore = async () => {
    setLoading(true);
    try {
      const result = await lawyerService.searchLawyers(
        searchTerm,
        selectedSpecialization,
        selectedLocation,
        offset,
        limit
      );
      setLawyers(prev => [...prev, ...result.data]);
      setHasMore(result.hasMore);
      setOffset(prev => prev + limit);
    } catch (error) {
      console.error('Error loading more lawyers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSearchTerm('');
    setSelectedSpecialization('All Specializations');
    setSelectedLocation('All Locations');
    fetchInitialLawyers();
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <h1 className="app-title">LegalIQ - Lawyer Directory</h1>
          <p className="app-subtitle">Find and Connect with Legal Professionals</p>
        </div>
      </header>

      <main className="app-main">
        <div className="container">
          <SearchBar
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />

          <FilterSection
            selectedSpecialization={selectedSpecialization}
            selectedLocation={selectedLocation}
            onSpecializationChange={setSelectedSpecialization}
            onLocationChange={setSelectedLocation}
            onReset={handleReset}
          />

          <div className="results-info">
            <p className="results-count">
              Showing <strong>{lawyers.length}</strong> of <strong>{totalLawyers}</strong> {totalLawyers === 1 ? 'lawyer' : 'lawyers'}
            </p>
          </div>

          {loading && lawyers.length === 0 ? (
            <div className="loading-container">
              <div className="loading-spinner"></div>
              <p>Loading lawyers...</p>
            </div>
          ) : lawyers.length > 0 ? (
            <>
              <div className="lawyers-grid">
                {lawyers.map((lawyer) => (
                  <LawyerCard key={lawyer.id} lawyer={lawyer} />
                ))}
              </div>
              
              {hasMore && (
                <div className="load-more-container">
                  <button
                    className="load-more-btn"
                    onClick={handleLoadMore}
                    disabled={loading}
                  >
                    {loading ? 'Loading...' : 'Load More Lawyers'}
                  </button>
                  <p className="load-more-text">
                    {totalLawyers - lawyers.length} more lawyers available
                  </p>
                </div>
              )}
            </>
          ) : (
            <div className="no-results">
              <div className="no-results-icon">🔍</div>
              <h3>No lawyers found</h3>
              <p>Try adjusting your search criteria or filters</p>
              <button className="reset-btn-large" onClick={handleReset}>
                Reset All Filters
              </button>
            </div>
          )}
        </div>
      </main>

      <footer className="app-footer">
        <p>&copy; 2024 LegalIQ. All rights reserved.</p>
      </footer>
    </div>
  );
}

// Protected Route Component
function ProtectedRoute({ children }) {
  const isAuthenticated = authService.isAuthenticated();
  return isAuthenticated ? children : <Navigate to="/login" />;
}

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const currentUser = authService.getUser();
    setUser(currentUser);
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleRegister = (userData) => {
    setUser(userData);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/register" element={<Register onRegister={handleRegister} />} />
        <Route path="/lawyers" element={<LawyersDirectory />} />
        <Route 
          path="/appointments" 
          element={
            <ProtectedRoute>
              <AppointmentManager userEmail={user?.email || 'user@example.com'} />
            </ProtectedRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
