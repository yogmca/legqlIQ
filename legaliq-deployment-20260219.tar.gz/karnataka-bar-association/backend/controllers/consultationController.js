const Consultation = require('../models/Consultation');
const Lawyer = require('../models/Lawyer');
const User = require('../models/User');
const mongoose = require('mongoose');

// Create a new consultation
exports.createConsultation = async (req, res) => {
  try {
    const {
      lawyerId,
      lawyerName,
      lawyerEmail,
      caseType,
      caseDescription,
      preferredDate,
      preferredTime,
      name,
      email,
      phone
    } = req.body;

    // Get authenticated user ID from request (set by auth middleware)
    const clientId = req.user.id;

    // Try to find lawyer in MongoDB, if not found, create a temporary ObjectId
    let lawyer = await Lawyer.findById(lawyerId);
    let actualLawyerId = lawyerId;
    
    // If lawyer doesn't exist in MongoDB (using fallback data), create a placeholder
    if (!lawyer && mongoose.Types.ObjectId.isValid(lawyerId)) {
      actualLawyerId = lawyerId;
    } else if (!lawyer) {
      // Create a new ObjectId for this lawyer
      actualLawyerId = new mongoose.Types.ObjectId();
    }

    // Create consultation
    const consultation = await Consultation.create({
      clientId,
      lawyerId: actualLawyerId,
      clientInfo: {
        name: name || req.user.name,
        email: email || req.user.email,
        phone: phone || req.user.phone
      },
      lawyerInfo: {
        name: lawyerName || (lawyer ? lawyer.name : 'Unknown'),
        email: lawyerEmail || (lawyer ? lawyer.email : ''),
        specialization: lawyer ? lawyer.specialization : []
      },
      caseType,
      caseDescription,
      preferredDate,
      preferredTime,
      status: 'pending'
    });

    res.status(201).json({
      success: true,
      message: 'Consultation booked successfully',
      consultation: consultation.getSummary()
    });
  } catch (error) {
    console.error('Create consultation error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to book consultation'
    });
  }
};

// Get all consultations for authenticated user
exports.getUserConsultations = async (req, res) => {
  try {
    const { status, limit = 50 } = req.query;
    const clientId = req.user.id;

    const consultations = await Consultation.getByClient(clientId, {
      status,
      limit: parseInt(limit)
    });

    res.status(200).json({
      success: true,
      consultations,
      total: consultations.length
    });
  } catch (error) {
    console.error('Get user consultations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch consultations'
    });
  }
};

// Get consultation by ID
exports.getConsultationById = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const consultation = await Consultation.findById(id)
      .populate('lawyerId', 'name email phone specialization rating')
      .populate('clientId', 'name email phone');

    if (!consultation) {
      return res.status(404).json({
        success: false,
        message: 'Consultation not found'
      });
    }

    // Check if user is authorized to view this consultation
    if (consultation.clientId._id.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to view this consultation'
      });
    }

    res.status(200).json({
      success: true,
      consultation
    });
  } catch (error) {
    console.error('Get consultation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch consultation'
    });
  }
};

// Update consultation status
exports.updateConsultationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, videoCallData, notes } = req.body;
    const userId = req.user.id;

    const consultation = await Consultation.findById(id);

    if (!consultation) {
      return res.status(404).json({
        success: false,
        message: 'Consultation not found'
      });
    }

    // Check if user is authorized
    if (consultation.clientId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this consultation'
      });
    }

    // Update fields
    if (status) consultation.status = status;
    if (videoCallData) consultation.videoCallData = videoCallData;
    if (notes) consultation.notes = notes;

    await consultation.save();

    res.status(200).json({
      success: true,
      message: 'Consultation updated successfully',
      consultation: consultation.getSummary()
    });
  } catch (error) {
    console.error('Update consultation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update consultation'
    });
  }
};

// Cancel consultation
exports.cancelConsultation = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const consultation = await Consultation.findById(id);

    if (!consultation) {
      return res.status(404).json({
        success: false,
        message: 'Consultation not found'
      });
    }

    // Check if user is authorized
    if (consultation.clientId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to cancel this consultation'
      });
    }

    // Check if consultation can be cancelled
    if (consultation.status === 'completed' || consultation.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: `Cannot cancel a ${consultation.status} consultation`
      });
    }

    consultation.status = 'cancelled';
    consultation.cancelledAt = Date.now();
    await consultation.save();

    res.status(200).json({
      success: true,
      message: 'Consultation cancelled successfully',
      consultation: consultation.getSummary()
    });
  } catch (error) {
    console.error('Cancel consultation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to cancel consultation'
    });
  }
};

// Add rating and review
exports.addReview = async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, review } = req.body;
    const userId = req.user.id;

    const consultation = await Consultation.findById(id);

    if (!consultation) {
      return res.status(404).json({
        success: false,
        message: 'Consultation not found'
      });
    }

    // Check if user is authorized
    if (consultation.clientId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to review this consultation'
      });
    }

    // Check if consultation is completed
    if (consultation.status !== 'completed') {
      return res.status(400).json({
        success: false,
        message: 'Can only review completed consultations'
      });
    }

    // Check if already reviewed
    if (consultation.rating) {
      return res.status(400).json({
        success: false,
        message: 'Consultation already reviewed'
      });
    }

    consultation.rating = rating;
    consultation.review = review;
    consultation.reviewedAt = Date.now();
    await consultation.save();

    // Update lawyer's average rating
    const lawyer = await Lawyer.findById(consultation.lawyerId);
    if (lawyer) {
      const consultations = await Consultation.find({
        lawyerId: lawyer._id,
        rating: { $exists: true }
      });
      
      const totalRating = consultations.reduce((sum, c) => sum + c.rating, 0);
      lawyer.rating = totalRating / consultations.length;
      lawyer.totalReviews = consultations.length;
      await lawyer.save();
    }

    res.status(200).json({
      success: true,
      message: 'Review added successfully',
      consultation: consultation.getSummary()
    });
  } catch (error) {
    console.error('Add review error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add review'
    });
  }
};

// Get consultation statistics for user
exports.getConsultationStats = async (req, res) => {
  try {
    const userId = req.user.id;

    const stats = await Consultation.aggregate([
      { $match: { clientId: mongoose.Types.ObjectId(userId) } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const total = await Consultation.countDocuments({ clientId: userId });

    res.status(200).json({
      success: true,
      stats: {
        total,
        byStatus: stats.reduce((acc, stat) => {
          acc[stat._id] = stat.count;
          return acc;
        }, {})
      }
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch statistics'
    });
  }
};
